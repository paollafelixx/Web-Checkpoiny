import styled from 'styled-components';

const HomeContainer = styled.div`
  background: ${(props) => (props.theme === 'dark' ? 'black' : 'white')};
  color: ${(props) => (props.theme === 'dark' ? 'white' : 'black')};
  // Adicione outras estilizações conforme necessário
`;

function Home(props) {
  return (
    <HomeContainer theme={props.theme}>
      <h1>Ecossistema Brasileiro</h1>
      <p>
        O Brasil é um país imenso, tanto em espaço territorial como em variedade de sua fauna, flora, clima, entre outros aspectos. Vejamos, a seguir, os principais ecossistemas brasileiros.
<ul>
<li>Amazônia: é o maior ecossistema brasileiro, possui uma grande diversidade, tanto de flora quanto de fauna. Esse ecossistema ocupa cerca de 60% do nosso país.</li>
<li>Cerrado: ocupa o segundo lugar no quesito extensão territorial, só perde para a Amazônia.</li>
<li>Caatinga: está em grande parte da região Nordeste do nosso país. Em geral, sua fauna e sua flora são bem adaptadas ao clima seco e quente dessa região.</li>
<li>Mata Atlântica: é o ecossistema mais referido quando o assunto é preservação. Em nosso país, ele abrange a costa leste, nordeste, sudeste e sul.</li>
<li>Pantanal: é considerado o menor bioma brasileiro, com cerca de 250 km² de extensão, e abrange cerca de 1,76% do território nacional. Em contrapartida, ele é tido como a maior planície inundada do mundo.</li>
<li>Manguezal: é considerado um ecossistema de transição, pois ocorre onde há encontro da água doce com água salgada, nas regiões tropicais e subtropicais do planeta.</li>
<li>Mata dos Cocais: é considerada um ecossistema de transição entre a Floresta Amazônica e a Caatinga.</li>
</ul>
</p>
    </HomeContainer>
  );
}

export default Home;
