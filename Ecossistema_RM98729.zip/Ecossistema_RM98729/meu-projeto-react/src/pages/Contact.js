import React, { useState } from 'react';
import axios from 'axios';

function Contact() {
  const [cep, setCep] = useState('');
  const [address, setAddress] = useState({});

  const handleCepChange = (e) => {
    const newCep = e.target.value;
    setCep(newCep);

    if (newCep.length === 8) {
      // Consulta à API ViaCEP
      axios.get(`https://viacep.com.br/ws/${newCep}/json/`)
        .then((response) => setAddress(response.data))
        .catch((error) => console.error(error));
    }
  };

  return (
    <div>
      <h1>Página de Contato</h1>
      <input
        type="text"
        placeholder="CEP"
        value={cep}
        onChange={handleCepChange}
      />
      <div>
        <p>Rua: {address.logradouro}</p>
        <p>Bairro: {address.bairro}</p>
        <p>Cidade: {address.localidade}</p>
        <p>Estado: {address.uf}</p>
      </div>
    </div>
  );
}

export default Contact;
