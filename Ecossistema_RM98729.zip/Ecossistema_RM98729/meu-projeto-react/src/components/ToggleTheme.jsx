import React from 'react';

function ToggleTheme(props) {
  return (
    <div>
      <button onClick={props.toggleTheme}>
        Toggle Theme (atual: {props.theme})
      </button>
    </div>
  );
}

export default ToggleTheme;
